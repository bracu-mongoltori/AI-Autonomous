# ARTag-Detection
ARtag detection with Aruco library 

Necessary library:
*numpy
*opencv-contrib-python version below 4.7 (pip install opencv-contrib-python==4.6.0.66)

N.B: Realsense Depth needs to be in the same folder as detect distance
